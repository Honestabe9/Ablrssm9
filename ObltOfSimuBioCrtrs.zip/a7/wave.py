"""
Subcontroller module for Alien Invaders

This module contains the subcontroller to manage a single level or wave in the Alien
Invaders game.  Instances of Wave represent a single wave.  Whenever you move to a
new level, you are expected to make a new instance of the class.

The subcontroller Wave manages the ship, the aliens and any laser bolts on screen.
These are model objects.  Their classes are defined in models.py.

Most of your work on this assignment will be in either this module or models.py.
Whether a helper method belongs in this module or models.py is often a complicated
issue.  If you do not know, ask on Piazza and we will answer.

Mattehw Dressa, mtd67
Simon Ressom, sr863
12/04/18
"""
from game2d import *
from consts import *
from models import *
import random
#import app

# PRIMARY RULE: Wave can only access attributes in models.py via getters/setters
# Wave is NOT allowed to access anything in app.py (Subcontrollers are not permitted
# to access anything in their parent. To see why, take CS 3152)


class Wave(object):
    """
    This class controls a single level or wave of Alien Invaders.

    This subcontroller has a reference to the ship, aliens, and any laser bolts on screen.
    It animates the laser bolts, removing any aliens as necessary. It also marches the
    aliens back and forth across the screen until they are all destroyed or they reach
    the defense line (at which point the player loses). When the wave is complete, you
    should create a NEW instance of Wave (in Invaders) if you want to make a new wave of
    aliens.

    If you want to pause the game, tell this controller to draw, but do not update.  See
    subcontrollers.py from Lecture 24 for an example.  This class will be similar to
    than one in how it interacts with the main class Invaders.

    #UPDATE ME LATER
    INSTANCE ATTRIBUTES:
        _ship:   the player ship to control [Ship]
        _aliens: the 2d list of aliens in the wave [rectangular 2d list of Alien or None]
        _bolts:  the ship laser bolts currently on screen [list of Bolt, possibly empty]
        _dline:  the defensive line being protected [GPath]
        _lives:  the number of lives left  [int >= 0]
        _time:   the amount of time since the last Alien "step" [number >= 0]

    As you can see, all of these attributes are hidden.  You may find that you want to
    access an attribute in class Invaders. It is okay if you do, but you MAY NOT ACCESS
    THE ATTRIBUTES DIRECTLY. You must use a getter and/or setter for any attribute that
    you need to access in Invaders.  Only add the getters and setters that you need for
    Invaders. You can keep everything else hidden.

    You may change any of the attributes above as you see fit. For example, may want to
    keep track of the score.  You also might want some label objects to display the score
    and number of lives. If you make changes, please list the changes with the invariants.

    LIST MORE ATTRIBUTES (AND THEIR INVARIANTS) HERE IF NECESSARY
    _pew_noise: noise of "pew" for each ship and alien bolt[Sound]
    _pop_noise: the "pop" sound for each ship and alien[Sound]
    _is_playerbolt: control that validates a single bolt from ship is on \
    screen [bool]
    _alien_downwards: a type of checking point to see if alien should move \
    downwards at boundary [bool]
    _alien_step: amount of steps alien has taken since its last step \
    [number >= 0]
    _alien_stepshoot: amount of steps needed before the next shot from bolt \
    [int >= 0]
    _alien_Bolts: alien laser bolts on screen at present time [list of Bolt, \
    possibly empty]
    _alien_amount: amount of aliens currently displayed on the screen [int]
    _blast_noise: the "blast" sound indicating ships demise [Sound]
    _alispeed: alien speed [number >= 0]
    _paused: paused state of the game [bool]
    _livescount: text in top right hand corner of screen that displays amount \
    of lives remaining [GLabel]
    _alien_X: Number of steps alien has to move in x-direction(horizontal)\
    [int >= 0]
    _alien_Y: Number of steps alien has to move in y-direction(vertical) \
    [int >= 0]
    _completion: state of game that indicates completion, can be 'Lose' or \
    'Win' or even neither [string]
    _alienActiveDown: designates if alien should go in downwards direction [bool]
    _alienplusX: number of steps in horizontal direction alien has to take \
    [int >= 0]
    _alienplusY: number of steps in vertical direction alien has to take \
    [int >= 0]
    """


    def __init__(self):
        """
        Initializer: Creates the Wave controller
        """
        self._ship = Ship()
        self._aliens = self.alienset()
        self._dline = GPath(linewidth = 1, points = [0, \
        DEFENSE_LINE, GAME_WIDTH,
        DEFENSE_LINE], linecolor = 'black')
        self._lives = 3
        self._time = 0
        self._alien_Bolts = []
        self._bolts = []
        self._alien_Bolts = []
        self._time = 0
        self._is_playerbolt = False
        self._alien_X = ALIEN_H_WALK
        self._alien_Y = ALIEN_V_WALK
        self._alienplusX = ALIEN_H_WALK
        self._alienplusY = ALIEN_V_WALK
        self._alien_downwards = False
        self._alien_steps = 0
        self._alien_stepshoot = random.randrange(1, BOLT_RATE)
        self._alien_amount = ALIEN_ROWS * ALIENS_IN_ROW
        self._blast_noise = Sound('blast1.wav')
        self._pew_noise = Sound('pew1.wav')
        self._pop_noise = Sound('pop1.wav')
        self._livescount = GLabel(text = 'Lives ' + str(self._lives),
        x = GAME_WIDTH - 90, y = GAME_HEIGHT - 30, halign = 'left', valign = \
        'middle',
                            font_size = 50, font_name = 'Arcade.ttf')
        self._paused = False
        self._alispeed = ALIEN_SPEED
        self._alienActiveDown = False
        self._completion = 'None'


    def getPaused(self):
        """
        Returns: the _paused status of the game
        """
        return self._paused


    def setPaused(self, value):
        """
        Sets the _paused status to value

        Parameter value: the new True or False _paused status
        Precondition: value is a bool
        """
        assert isinstance(value, bool)
        self._paused = value


    def getLives(self):
        """
        Returns the current in-game life count
        """
        return self._lives


    def setLives(self, value):
        """
        Sets the current in-game life count to value

        Parameter value: the new in-game life count
        Precondition: value is an int and value >= 0
        """
        assert isinstance(value, int) and value >= 0
        self._lives = value


    def getCompletion(self):
        """
        Returns: the _completion status of hte game
        """
        return self._completion


    def draw(self, view):
        """
        Draws the ship, aliens, bolts, and life label onto the screen

        Parameter view: the view window
        Precondition: view is a GView
        """
        self._dline.draw(view)
        self._ship.draw(view)

        self._livescount.text  = ('Lives ' + str(self._lives))
        self._livescount.draw(view)

        for row in self._aliens:
            for col in row:
                if col != None:
                    col.draw(view)

        for bolt in self._alien_Bolts:
            self.boltTracking(bolt, 'toShip', view)

        for bolt in self._bolts:
            if self._bolts != None:
                self.boltTracking(bolt, 'toAlien', view)


    def update(self, drn, dt):
        """
        Animates a single frame in the game

        This method first checks for any win or loss indicators; if it does not
        find any, then it executes the game.
        The win or loss indicators are as follows:
        Win: when the alien count = 0
        Loss: when the ship life count = 0
        Loss 2: when the aliens have crossed the line

        Parameter drn: the keyboard input
        Precondition: drn is a GInput

        Parameter dt: The time in seconds since last update
        Precondition: dt is a number (int or float)
        """
        if self._lives == 0:
            self._completion = 'Lose'
        elif self._alien_amount == 0:
            self._completion = 'Win'
        elif self._paused == True:
            pass
        elif self.alienInva() == True:
            self._completion = 'Lose'
        else:
            self.collision_detect()
            self.boltAction(drn)
            self.shipMotion(drn)
            self._time += dt
            if self._alien_steps == self._alien_stepshoot:
                self.alien_Fire()
                self._alien_steps = 0
            if self._time > self._alispeed:
                self._alien_steps += 1
                self.alienMotion()


    def shipMotion(self, drn):
        """
        Administers ship from left to right

        Parameter drn: the keyboard input
        Precondition: drn is a GInput
        """
        self._ship.motion(drn)


    def boltAction(self, drn):
        """
        Creates a bolt when the spacebar is pressed

        Parameter drn: the keyboard input
        Precondition: drn is a GInput
        """
        if drn.is_key_down('spacebar') and self._is_playerbolt == False:
            #bolt detection
            self._pew_noise = Sound('pew1.wav')
            self._pew_noise.play()
            bolt = Bolt(self._ship.getX(), self._ship.getY()
            + SHIP_HEIGHT / 2 + BOLT_HEIGHT / 2)
            self._bolts.append(bolt)
            self._is_playerbolt = True


    def alienset(self):
        """
        Returns the two-dimensional list of aliens
        """
        colaccum = []

        imageFactor = 0
        for row in range(ALIEN_ROWS):
            rowaccum = []
            for column in range(ALIENS_IN_ROW):
                xpos = ALIEN_H_SEP * (column + 1) + ALIEN_WIDTH * (column + 1)
                ypos = GAME_HEIGHT - ALIEN_CEILING - ALIEN_V_SEP * (row -1) \
                - ALIEN_HEIGHT * row
                rowaccum.append(Alien(xpos, ypos, ALIEN_IMAGES[imageFactor]))
            colaccum.append(rowaccum)
            if(row % 2 == 0 and imageFactor == 0):
                imageFactor = 2
            elif(row % 2 == 0 and imageFactor <= 2 and imageFactor > 0):
                imageFactor -= 1
        return colaccum


    def boltTracking(self, bolt, boltversion, display):
        """
        If bolt surpasses y-boundary for screen then the bolt is deleted.
        Otherwise, allows it to move upwards or downwards depending
        on the bolt type

        Parameter bolt: the laser bolt
        Precondition: bolt is of class Bolt

        Parameter boltversion: the bolt aimed at either an alien or the ship
        Precondition: boltversion is a string that is either 'toAlien' or
        'toShip'

        Parameter display: the display window
        Precondition: display is a GView
        """
        if boltversion == 'toShip':
            if bolt.getY() + BOLT_HEIGHT / 2 < 0:
                del self._alien_Bolts[self._alien_Bolts.index(bolt)]
            else:
                bolt.draw(display)
                bolt.shootAlienBolt()
        elif boltversion == 'toAlien':
            if bolt.getY() + BOLT_HEIGHT / 2 > GAME_HEIGHT:
                del self._bolts[self._bolts.index(bolt)]
                self._is_playerbolt = False
            else:
                bolt.shootPlayerBolt()
                bolt.draw(display)
                self._is_playerbolt = True


    def collision_detect(self):
        """
        Detects collision for either alien and upward bolt or ship and downward
        bolt
        """
        for row in range(len(self._aliens)):
            for column in range(len(self._aliens[row])):
                for bolt in range(len(self._bolts)):
                    if self._aliens[row][column] != None:
                        if self._aliens[row][column].\
                        collision(self._bolts[bolt]) == True:
                            self._aliens[row][column] = None
                            self._alispeed *= 0.92
                            self._is_playerbolt = False
                            del self._bolts[bolt]
                            self._pop_noise.play()
                            self._alien_amount -= 1
                for bolt2 in self._alien_Bolts:
                    x = False
                    if self._ship.collision(bolt2) == True:
                        del bolt2
                        self._blast_noise.play()
                        self._paused = True


    def alienMotion(self,):
        """
        Deals with alien motion
        """
        flatList = []
        for row in range(ALIEN_ROWS):
            for col in range(ALIENS_IN_ROW):
                if self._aliens[row][col] != None:
                    flatList.append(self._aliens[row][col].getX())

        self.edge_detect(flatList)

        for row in range(ALIEN_ROWS):
            for col in range(ALIENS_IN_ROW):
                if self._aliens[row][col] != None:
                        self._aliens[row][col].x += self._alienplusX
                        self._aliens[row][col].y += self._alienplusY
        self._time = 0


    def edge_detect(self, flatList):
        """
        Handles edge detection for alien movement

        Parameter flatList: the flatList of alien x-values to check against
        screen boundaries
        Precondition: flatList is a list of floats (alien x-values)
        """
        if self._alienActiveDown == True:
            if max(flatList) > GAME_WIDTH - ALIEN_H_SEP - ALIEN_WIDTH:
                self._alienplusX = -ALIEN_H_WALK
            elif min(flatList) < ALIEN_H_SEP + ALIEN_WIDTH:
                self._alienplusX = ALIEN_H_WALK
            self._alienplusY = 0
            self._alienActiveDown = False
        elif max(flatList) > GAME_WIDTH - ALIEN_H_SEP - ALIEN_WIDTH:
            self._alienplusX = 0
            self._alienplusY = -ALIEN_V_WALK
            self._alienActiveDown = True
        elif min(flatList) < ALIEN_H_SEP + ALIEN_WIDTH:
            self._alienplusX = 0
            self._alienplusY = -ALIEN_V_WALK
            self._alienActiveDown = True
        else:
            self._alienplusX = self._alienplusX
            self._alienplusY = 0
    #     list = []


    def alienInva(self):
        """
        Returns True if the bottom-most aliens y-value has passed the defensive
        line; otherwise, it returns False

        The method checks to see if the bottom-most alien y-value has crossed
        the defensive line
        """
        bottomaccu = []
        while bottomaccu == []:
            for row in range(ALIEN_ROWS):
                for col in range(ALIENS_IN_ROW):
                    if self._aliens[row][col] != None:
                        bottomaccu.append(self._aliens[row][col].getY())

        if bottomaccu != []:
            if min(bottomaccu) - ALIEN_HEIGHT / 2 < self._dline.points[1]:
                return True
            else:
                return False


    def alien_Fire(self):
        """
        Identifies a random column and locates its bottom-most alien to fire a
        bolt downwards
        """
        randCol = random.randrange(0, ALIENS_IN_ROW)
        bottomaccu = []
        while bottomaccu == []:
            for row in range(ALIEN_ROWS):
                if self._aliens[row][randCol] != None:
                    bottomaccu.append(self._aliens[row][randCol].getY())
            if bottomaccu == []:
                randCol = random.randrange(0, ALIENS_IN_ROW)

        alien = bottomaccu.index(min(bottomaccu))

        if bottomaccu != [] and self._aliens[alien][randCol] != None:
            self._pew_noise = Sound('pew2.wav')
            self._pew_noise.play()
            bolt = Bolt(self._aliens[alien][randCol].getX(),
            self._aliens[alien][randCol].getY()) #not min
            self._alien_Bolts.append(bolt)
